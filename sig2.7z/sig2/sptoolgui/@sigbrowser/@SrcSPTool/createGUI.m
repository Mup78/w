function plugInGUI = createGUI(~)
%CreateGUI Build and cache UI plug-in.
%   This override prevents the default buttons/sources
%   from being added to the scope.
%   No install/render needs to be done here.

% Copyright 2012 The MathWorks, Inc.

plugInGUI = [];

% [EOF]
