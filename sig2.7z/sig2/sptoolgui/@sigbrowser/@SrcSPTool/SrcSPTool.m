function this = SrcSPTool(varargin)
% Constructor for SPTool-based datasource

% Copyright 2012 The MathWorks, Inc.

this = sigbrowser.SrcSPTool;
this.initSource(varargin{:});

% [EOF]
