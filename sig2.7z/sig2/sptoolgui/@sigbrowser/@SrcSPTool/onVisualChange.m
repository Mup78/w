function onVisualChange(~)
%ONVISUALCHANGE 
%   SPTool does not currently change the visual.  

%   Copyright 2012 The MathWorks, Inc.

% [EOF]
