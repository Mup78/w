function numInputs = getNumInputs(this)
%GETNUMINPUTS Get the numInputs.

%   Copyright 2012 The MathWorks, Inc.

numInputs = numel(this.Signals);

% [EOF]
