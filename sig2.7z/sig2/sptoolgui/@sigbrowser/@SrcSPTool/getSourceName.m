function srcStr = getSourceName(~)
%

%   Copyright 2012 The MathWorks, Inc.

srcStr = '';

% [EOF]
