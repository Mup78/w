function enableData(this)
%ENABLEDATA 

%   Copyright 2012 The MathWorks, Inc.

updateDisplay(this);

% [EOF]
