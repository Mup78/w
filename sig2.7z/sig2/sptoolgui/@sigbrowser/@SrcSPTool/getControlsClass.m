function controlsClass = getControlsClass(~)
%GETCONTROLSCLASS Get the controlsClass.

%   Copyright 2012 The MathWorks, Inc.

controlsClass = 'matlabshared.scopes.source.PlaybackControlsNull';

% [EOF]
