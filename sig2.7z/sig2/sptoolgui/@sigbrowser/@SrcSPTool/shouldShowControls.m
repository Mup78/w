function flag = shouldShowControls(~, ~)
%SHOULDSHOWCONTROLS For source specific control visibility
% Returns true if the controls should be visible on the scope

%   Copyright 2012 The MathWorks, Inc.

flag = false;

end

