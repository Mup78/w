function fdqexists = qfiltexists
%QFILTEXISTS  Test to see if the QFILT constructor exists.

%   Copyright 1988-2004 The MathWorks, Inc.

fdqexists = isfdtbxinstalled;

% [EOF]
