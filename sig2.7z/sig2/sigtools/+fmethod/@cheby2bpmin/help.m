function help(this)
%HELP   

%   Copyright 1999-2015 The MathWorks, Inc.

help_cheby2(this);
help_matchexactly(this);
if isfdtbxinstalled
    help_sosscale(this);
end
help_examples(this);

% [EOF]
