function examples = getexamples(this)
%GETEXAMPLES   Get the examples.

%   Copyright 1999-2015 The MathWorks, Inc.

examples = {{...
    'Complex Bandpass Filter',...
    'f=fdesign.arbmagnphase(''N,F,H'',100);',...
    'design(f,''equiripple'');',...
    }};


% [EOF]


