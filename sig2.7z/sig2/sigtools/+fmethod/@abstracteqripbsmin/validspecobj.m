function s = validspecobj(~)
%VALIDSPECOBJ   

%   Copyright 1999-2015 The MathWorks, Inc.

s = 'fspecs.bsmin';

% [EOF]
