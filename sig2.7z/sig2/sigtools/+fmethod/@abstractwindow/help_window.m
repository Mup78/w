function help_window(this)
%HELP_WINDOW   

%   Copyright 1999-2015 The MathWorks, Inc.

help_header(this, 'window', 'Windowed', 'FIR');

% [EOF]
