function help_kaiser(this)
%HELP_KAISER   

%   Copyright 1999-2015 The MathWorks, Inc.

help_header(this, 'kaiserwin', 'Kaiser windowed', 'FIR');

% [EOF]
