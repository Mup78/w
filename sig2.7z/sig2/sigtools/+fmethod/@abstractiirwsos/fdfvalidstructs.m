function validstructs = fdfvalidstructs(this)
%FDFVALIDSTRUCTS   

%   Copyright 1999-2015 The MathWorks, Inc.


validstructs = {'df1sos','df2sos','df1tsos','df2tsos',...
    'cascadeallpass','cascadewdfallpass'};

% [EOF]
