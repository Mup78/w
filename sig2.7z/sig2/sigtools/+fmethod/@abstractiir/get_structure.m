function structure = get_structure(this, structure)
%GET_STRUCTURE   PreGet function for the 'structure' property.

%   Copyright 1999-2015 The MathWorks, Inc.

if isempty(structure)
    structure = 'df2sos';
end

% [EOF]
