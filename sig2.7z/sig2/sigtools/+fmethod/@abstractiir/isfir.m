function b = isfir(this)
%ISFIR   True if the object is fir.

%   Copyright 1999-2015 The MathWorks, Inc.

b = false;

% [EOF]
