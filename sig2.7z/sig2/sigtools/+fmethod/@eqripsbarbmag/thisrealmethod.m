function m = thisrealmethod(~)
%THISREALMETHOD   

%   Copyright 1999-2015 The MathWorks, Inc.

m = @firpm;

% [EOF]
