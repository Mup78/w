function m = thiscomplexmethod(~)
%THISCOMPLEXMETHOD   

%   Copyright 1999-2015 The MathWorks, Inc.

m = @cfirpm;

% [EOF]
