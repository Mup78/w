function b = thisforcelinearphase(this,b)
%THISFORCELINEARPHASE   

%   Copyright 1999-2015 The MathWorks, Inc.

% No op.

% [EOF]
