function help(this)
%HELP   

%   Copyright 1999-2015 The MathWorks, Inc.


help_firls(this);
help_weight(this, 'Weights');
help_examples(this);

% [EOF]
