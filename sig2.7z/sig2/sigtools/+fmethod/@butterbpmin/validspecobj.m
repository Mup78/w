function str = validspecobj(h)
%VALIDSPECOBJ   

%   Copyright 1999-2015 The MathWorks, Inc.

str = 'fspecs.bpmin';

% [EOF]
