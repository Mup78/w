function validate(h,specs)
%VALIDATE   Perform algorithm specific spec. validation.

%   Copyright 1999-2015 The MathWorks, Inc.



% [EOF]
