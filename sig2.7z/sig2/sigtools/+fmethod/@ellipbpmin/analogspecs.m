function has = analogspecs(h,hs)
%ANALOGSPECS   Compute analog specifications object.

%   Copyright 1999-2015 The MathWorks, Inc.

has = minanalogspecs(h,hs);

% [EOF]
