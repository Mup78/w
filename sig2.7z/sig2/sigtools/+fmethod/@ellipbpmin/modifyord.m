function N = modifyord(this,N)
%MODIFYORD   

%   Copyright 1999-2015 The MathWorks, Inc.

N = bpbsmodifyord(this,N);

% [EOF]
