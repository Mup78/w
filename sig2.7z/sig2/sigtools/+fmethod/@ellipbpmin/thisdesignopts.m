function s = thisdesignopts(this, s)
%THISDESIGNOPTS   

%   Copyright 1999-2015 The MathWorks, Inc.

% NO OP.

% [EOF]
