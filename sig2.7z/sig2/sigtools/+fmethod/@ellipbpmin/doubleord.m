function bl = doubleord(h)
%DOUBLEORD   Return true if filter order must be doubled.

%   Copyright 1999-2015 The MathWorks, Inc.

% Order must be doubled
bl = true;

% [EOF]
