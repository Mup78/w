function s = validspecobj(this)
%VALIDSPECOBJ   Returns the name of the valid specification object.

%   Copyright 1999-2015 The MathWorks, Inc.

s = 'fspecs.lpcutoffwatten';

% [EOF]
