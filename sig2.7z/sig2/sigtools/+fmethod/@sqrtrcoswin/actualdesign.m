function b = actualdesign(this, hspecs, varargin)
%ACTUALDESIGN <short description>
%   OUT = ACTUALDESIGN(ARGS) <long description>

%   Copyright 1999-2015 The MathWorks, Inc.

b = rcoswindesign(this, hspecs, 'sqrt');

% [EOF]
