function sosreorder = getsosreorder(this)
%GETSOSREORDER   Get the sosreorder.

%   Copyright 1999-2015 The MathWorks, Inc.

sosreorder = 'lowpass';

% [EOF]
