function str = validspecobj(h)
%VALIDSPECOBJ   Returns the valid specification object.

%   Copyright 1999-2015 The MathWorks, Inc.

str = 'fspecs.lp3db';

% [EOF]
