function [s,g] = bilineardesign(h,has,c)
%BILINEARDESIGN  Design digital filter from analog specs. using bilinear. 

%   Copyright 1999-2015 The MathWorks, Inc.

[s,g] = thisbilineardesign(h,has,c);

% [EOF]
