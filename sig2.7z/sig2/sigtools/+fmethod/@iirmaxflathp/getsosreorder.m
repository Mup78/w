function sosreorder = getsosreorder(~)
%GETSOSREORDER Get the sosreorder.

%   Copyright 1999-2015 The MathWorks, Inc.

sosreorder = 'highpass';

% [EOF]
