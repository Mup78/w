function Hd = createcaobj(this,struct,branch1,branch2)
%CREATECAOBJ   

%   Copyright 1999-2015 The MathWorks, Inc.

Hd = hpcreatecaobj(this,struct,branch1,branch2);

% [EOF]
