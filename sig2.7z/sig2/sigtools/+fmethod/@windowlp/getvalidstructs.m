function validstructs = getvalidstructs(this)
%GETVALIDSTRUCTS   Get the validstructs.

%   Copyright 1999-2015 The MathWorks, Inc.

validstructs = {'dffir', 'dffirt', 'dfsymfir', 'fftfir'};

% [EOF]
