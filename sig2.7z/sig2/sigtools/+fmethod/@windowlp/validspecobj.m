function vso = validspecobj(this)
%VALIDSPECOBJ   Return the valid specification object.

%   Copyright 1999-2015 The MathWorks, Inc.

vso = 'fspecs.lpcutoff';

% [EOF]
