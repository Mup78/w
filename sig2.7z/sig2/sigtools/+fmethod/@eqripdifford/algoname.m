function name = algoname(this)
%ALGONAME   Short design algorithm name

%   Copyright 1999-2015 The MathWorks, Inc.

name = 'Differentiators';

% [EOF]
