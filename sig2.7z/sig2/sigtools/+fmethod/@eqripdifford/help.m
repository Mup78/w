function help(this)
%HELP   

%   Copyright 1999-2015 The MathWorks, Inc.

help_equiripple(this);
help_densityfactor(this);
disp(['    ' getString(message('signal:sigtools:fmethod:NoticeThatTheFilterOrderMustBeOdd'))]);
disp(' ');

help_examples(this);

% [EOF]
