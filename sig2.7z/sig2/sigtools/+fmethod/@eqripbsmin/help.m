function help(this)
%HELP   

%   Copyright 1999-2015 The MathWorks, Inc.

help_equiripple(this);
help_densityfactor(this);
help_examples(this);

% [EOF]
