function matchexactly = get_matchexactly(this, matchexactly)
%GET_MATCHEXACTLY   PreGet function for the 'matchexactly' property.

%   Copyright 1999-2015 The MathWorks, Inc.

matchexactly = this.privMatchExactly;

% [EOF]
