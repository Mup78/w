function help_butter(this)
%HELP_BUTTER   

%   Copyright 1999-2015 The MathWorks, Inc.

help_header(this, 'butter', 'Butterworth', 'IIR');

% [EOF]
