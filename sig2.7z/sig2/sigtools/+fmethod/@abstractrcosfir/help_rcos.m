function help_rcos(this)
%HELP   

%   Copyright 1999-2015 The MathWorks, Inc.

help_header(this, 'window', 'raised cosine windowed', 'FIR');

% [EOF]
